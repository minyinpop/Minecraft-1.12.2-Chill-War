package net.blacklab.lmr.entity.maidmodel;

import net.minecraft.client.model.ModelBase;

public class ModelBaseNihil extends ModelBase{

}
